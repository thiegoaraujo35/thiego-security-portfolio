/* ============================================================
   EDIT YOUR CONTENT HERE. Plain data only — nothing below the
   "RENDERING" marker needs to be touched.
   ============================================================ */

const ABOUT = {
  role: "Cloud Security Engineer",
  focus: "Microsoft Security · Cloud Security · IAM & Zero Trust",
  location: "Fortaleza, Brazil (Remote — Worldwide)",
  paragraphs: [
    "I started my career in IT infrastructure — servers, virtualization, networking, backup — supporting critical corporate environments, including hospitals and educational institutions. That hands-on understanding of how systems actually work underneath is what shapes my approach to security today.",
    "I'm currently responsible for the architecture, deployment, and operation of a full Microsoft security environment — Defender XDR, Sentinel, Entra ID, and Purview — complemented by Prisma Cloud, Proofpoint, Cylance, and Picus Security. I work at the intersection of infrastructure, identity, and incident response, across Azure, AWS, and hybrid environments."
  ]
};

const SKILLS = {
  microsoft_security: ["Defender XDR", "Microsoft Sentinel (SIEM/SOAR)", "Entra ID", "Microsoft Purview"],
  cloud_security: ["Azure", "AWS", "Hybrid environments", "Prisma Cloud (CSPM/CWPP/CIEM)"],
  email_and_endpoint: ["Proofpoint (Email Security, TAP, DLP)", "CylancePROTECT", "CylanceOPTICS"],
  control_validation: ["Picus Security (Breach & Attack Simulation)"],
  infrastructure: ["Windows Server", "Active Directory", "VMware/Hyper-V", "Veeam", "Dell Storage"],
  process: ["ITIL", "Change Management (GMUD/CT)"]
};

/* status: "ACTIVE" for the current role, "PAST" for previous ones */
const EXPERIENCE = [
  {
    date: "2022-11", status: "ACTIVE",
    company: "TrustControl", role: "Cloud Security Engineer",
    formal: "formal title: Analista de Segurança em Cloud",
    notes: [
      "Architecture, implementation, and operation of Microsoft Defender XDR (Endpoint, Identity, Office 365, Cloud Apps)",
      "Sentinel (SIEM/SOAR): event correlation, automation, incident response playbooks",
      "Entra ID (Identity Protection, MFA, Conditional Access) — governance aligned to Zero Trust",
      "Purview (DLP, Information Protection, Compliance) for sensitive data",
      "Prisma Cloud (CSPM/CWPP/CIEM) across Azure, AWS, and hybrid environments",
      "Proofpoint (Email Security, TAP, DLP, Threat Response) and Cylance endpoint protection",
      "Continuous control validation via Picus Security (BAS)"
    ]
  },
  {
    date: "2022-01", status: "PAST",
    company: "UNIFOR", role: "IT Infrastructure Analyst",
    notes: [
      "Sustained and optimized VMware environments (HA, DRS, SDRS)",
      "Administered Windows Server and Active Directory",
      "Managed Dell storage and Veeam backup routines"
    ]
  },
  {
    date: "2019-06", status: "PAST",
    company: "SONDA / Resource IT", role: "IT Infrastructure Architect",
    notes: [
      "Administered Windows Server: AD, DNS, DHCP, IIS, Failover Clustering, Hyper-V, VMM",
      "Produced topology diagrams and technical documentation",
      "Authored formal Change Tickets (CTs)"
    ]
  },
  {
    date: "2018-08", status: "PAST",
    company: "NTSec", role: "IT Security Consultant",
    notes: [
      "Installed and configured Checkpoint / Sophos firewalls",
      "Resolved information security incidents",
      "Veeam backup, Aruba wireless, VMware, CyberArk (PAM)"
    ]
  },
  {
    date: "2013-09", status: "PAST",
    company: "Clínica Qorpo / Rede São Camilo", role: "IT Support / Supervisor",
    notes: [
      "Coordinated IT operations (ITIL); virtualized infrastructure (VMware/Hyper-V); firewalls and antivirus across hospital units"
    ]
  }
];

/* year: EDIT with the real year. url: paste the credential verification link when available. */
const CERTIFICATIONS = [
  { id: "SC-100", name: "Microsoft Certified: Cybersecurity Architect Expert", year: "20XX", url: "" },
  { id: "SC-200", name: "Microsoft Certified: Security Operations Analyst Associate", year: "20XX", url: "" },
  { id: "SC-300", name: "Microsoft Certified: Identity and Access Administrator Associate", year: "20XX", url: "" },
  { id: "SC-401", name: "Microsoft Certified: Information Security Administrator Associate", year: "20XX", url: "" },
  { id: "AZ-104", name: "Microsoft Certified: Azure Administrator Associate", year: "20XX", url: "" },
  { id: "AZ-500", name: "Microsoft Certified: Azure Security Engineer Associate", year: "20XX", url: "" },
  { id: "MS-500", name: "Microsoft 365 Certified: Security Administrator Associate", year: "20XX", url: "" },
  { id: "AZ-700", name: "Microsoft Certified: Azure Network Engineer Associate", year: "20XX", url: "" },
  { id: "VCP-DCV", name: "VMware Certified Professional – Data Center Virtualization", year: "20XX", url: "" },
  { id: "PROOFPT", name: "Proofpoint Certified AI Email Security Specialist", year: "20XX", url: "" },
  { id: "FORENS", name: "Análise Forense de Redes", year: "20XX", url: "" }
];

/* Add one entry per public project. Set url + wip:false once the repo is live. */
const PROJECTS = [
  {
    name: "kql-detection-library/",
    desc: "Documented KQL detection queries for Sentinel & Defender XDR, mapped to MITRE ATT&CK.",
    url: "", wip: true
  },
  {
    name: "secure-iac-templates.tf",
    desc: "Terraform modules for Azure, validated with tfsec/Checkov.",
    url: "", wip: true
  },
  {
    name: "ir-playbooks.md",
    desc: "Incident response playbooks: phishing, compromised account, endpoint malware.",
    url: "", wip: true
  }
];

const CONTACT = {
  linkedin: "https://www.linkedin.com/in/thiegoaraujo",
  linkedinLabel: "linkedin.com/in/thiegoaraujo",
  github: "https://github.com/YOUR-GITHUB-USERNAME",
  githubLabel: "github.com/YOUR-GITHUB-USERNAME",
  email: "thiego.info@gmail.com"
};

/* ============================================================
   RENDERING — no need to edit below this line.
   ============================================================ */

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function span(cls, text) { return `<span class="${cls}">${esc(text)}</span>`; }
function link(cls, href, text) { return `<a class="${cls} tok-link" href="${href}" target="_blank" rel="noopener">${esc(text)}</a>`; }

/* ---- about.md ---- */
function buildAboutLines() {
  const L = [];
  L.push(span("tok-heading", "# Thiego Araújo"));
  L.push("");
  L.push(span("tok-label", "role:") + "     " + span("tok-value", ABOUT.role));
  L.push(span("tok-label", "focus:") + "    " + span("tok-value", ABOUT.focus));
  L.push(span("tok-label", "location:") + " " + span("tok-value", ABOUT.location));
  L.push("");
  L.push(span("tok-heading", "## Summary"));
  L.push("");
  ABOUT.paragraphs.forEach(p => { L.push(p); L.push(""); });
  L.push(span("tok-comment", "// edit this section in assets/script.js → const ABOUT"));
  return L;
}

/* ---- skills.json ---- */
function syntaxHighlightJSON(json) {
  json = esc(json);
  return json.replace(
    /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    (match) => {
      let cls = "tok-number";
      if (/^"/.test(match)) cls = /:$/.test(match) ? "tok-key" : "tok-string";
      else if (/true|false/.test(match)) cls = "tok-bool";
      else if (/null/.test(match)) cls = "tok-null";
      return `<span class="${cls}">${match}</span>`;
    }
  );
}
function buildSkillsLines() {
  const json = JSON.stringify(SKILLS, null, 2);
  return syntaxHighlightJSON(json).split("\n");
}

/* ---- experience.log ---- */
function buildExperienceLines() {
  const L = [];
  EXPERIENCE.forEach((job, i) => {
    const tag = job.status === "ACTIVE" ? span("tok-tag-active", "[ACTIVE]") : span("tok-tag-past", "[PAST]  ");
    L.push(`${span("tok-dim", "[" + job.date + "]")} ${tag} ${span("tok-company", job.company)} ${span("tok-punct", "::")} ${span("tok-value", job.role)}`);
    if (job.formal) L.push("  " + span("tok-comment", "// " + job.formal));
    job.notes.forEach(n => L.push("  " + span("tok-comment", "// " + n)));
    if (i < EXPERIENCE.length - 1) L.push("");
  });
  return L;
}

/* ---- certifications.yaml ---- */
function buildCertLines() {
  const L = [];
  CERTIFICATIONS.forEach(c => {
    L.push(span("tok-punct", "- ") + span("tok-key", "id:") + "     " + span("tok-string", `"${c.id}"`));
    L.push("  " + span("tok-key", "name:") + "   " + span("tok-string", `"${c.name}"`));
    L.push("  " + span("tok-key", "year:") + "   " + span("tok-number", c.year));
    L.push(
      "  " + span("tok-key", "url:") + "    " +
      (c.url ? link("tok-string", c.url, `"${c.url}"`) : span("tok-comment", '""  # add credential link'))
    );
    L.push("");
  });
  L.pop();
  return L;
}

/* ---- projects/ ---- */
function buildProjectLines() {
  const L = [];
  L.push(span("tok-dim", "$ ls -la ./projects"));
  L.push("");
  PROJECTS.forEach(p => {
    const perms = p.wip ? span("tok-dim", "-rw-r--r--") : span("tok-tag-active", "drwxr-xr-x");
    const name = p.url
      ? link("tok-string", p.url, p.name)
      : span(p.wip ? "tok-dim" : "tok-string", p.name);
    const wip = p.wip ? " " + span("tok-wip", "[WIP]") : "";
    L.push(`${perms}  ${name}${wip}`);
    L.push("  " + span("tok-comment", "# " + p.desc));
    L.push("");
  });
  L.pop();
  return L;
}

/* ---- contact.sh ---- */
function buildContactLines() {
  const L = [];
  L.push(span("tok-comment", "#!/bin/bash"));
  L.push(span("tok-comment", "# contact.sh — reach out"));
  L.push("");
  L.push(span("tok-key", "LINKEDIN") + span("tok-punct", "=") + link("tok-string", CONTACT.linkedin, `"${CONTACT.linkedinLabel}"`));
  L.push(span("tok-key", "GITHUB") + span("tok-punct", "=") + link("tok-string", CONTACT.github, `"${CONTACT.githubLabel}"`));
  L.push(span("tok-key", "EMAIL") + span("tok-punct", "=") + link("tok-string", "mailto:" + CONTACT.email, `"${CONTACT.email}"`));
  L.push("");
  L.push(span("tok-value", "echo") + ` "Open to remote Cloud Security Engineer roles — worldwide."`);
  L.push(span("tok-value", "echo") + ` "Let's talk → $EMAIL"`);
  return L;
}

/* ---- assemble tabs ---- */
const TABS = [
  { id: "about", label: "about.md", color: "var(--blue)", lines: buildAboutLines(), ctas: false },
  { id: "skills", label: "skills.json", color: "var(--tan)", lines: buildSkillsLines(), ctas: false },
  { id: "experience", label: "experience.log", color: "var(--muted)", lines: buildExperienceLines(), ctas: false },
  { id: "certifications", label: "certifications.yaml", color: "var(--magenta)", lines: buildCertLines(), ctas: false },
  { id: "projects", label: "projects/", color: "var(--cyan)", lines: buildProjectLines(), ctas: false },
  { id: "contact", label: "contact.sh", color: "var(--green)", lines: buildContactLines(), ctas: true }
];

function renderTabsAndPanes() {
  const tabsEl = document.getElementById("tabs");
  const panesEl = document.getElementById("panes");
  const titleEl = document.getElementById("editorTitle");
  const sbFile = document.getElementById("sbFile");

  TABS.forEach((tab, i) => {
    const btn = document.createElement("button");
    btn.className = "tab";
    btn.setAttribute("role", "tab");
    btn.dataset.active = i === 0 ? "true" : "false";
    btn.innerHTML = `<span class="sq" style="background:${tab.color}"></span>${esc(tab.label)}`;
    btn.addEventListener("click", () => activateTab(tab.id));
    tabsEl.appendChild(btn);

    const pane = document.createElement("div");
    pane.className = "pane";
    pane.id = "pane-" + tab.id;
    pane.dataset.visible = i === 0 ? "true" : "false";
    const code = document.createElement("div");
    code.className = "code";
    tab.lines.forEach((line, idx) => {
      const row = document.createElement("div");
      row.className = "line";
      row.innerHTML = `<span class="ln">${idx + 1}</span><span class="code-text">${line === "" ? "&nbsp;" : line}</span>`;
      code.appendChild(row);
    });
    pane.appendChild(code);

    if (tab.ctas) {
      const ctaRow = document.createElement("div");
      ctaRow.className = "contact-ctas";
      ctaRow.innerHTML = `
        <a class="pill solid" href="mailto:${CONTACT.email}">✉ Email me</a>
        <a class="pill" href="${CONTACT.linkedin}" target="_blank" rel="noopener">in LinkedIn</a>
        <a class="pill" href="${CONTACT.github}" target="_blank" rel="noopener">⌥ GitHub</a>
        <a class="pill" href="assets/resume.pdf" download>⭳ Download résumé</a>
      `;
      pane.appendChild(ctaRow);
    }

    panesEl.appendChild(pane);
  });

  function activateTab(id) {
    document.querySelectorAll(".tab").forEach((btn, i) => {
      btn.dataset.active = TABS[i].id === id ? "true" : "false";
    });
    document.querySelectorAll(".pane").forEach(p => {
      p.dataset.visible = p.id === "pane-" + id ? "true" : "false";
    });
    const active = TABS.find(t => t.id === id);
    titleEl.textContent = "~/thiego-araujo/portfolio/" + active.label;
    sbFile.textContent = active.label;
  }
}

/* ---- terminal boot sequence ---- */
function typeTerminal() {
  const body = document.getElementById("termBody");
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const script = [
    { type: "cmd", text: "whoami" },
    { type: "out", text: "thiego-araujo" },
    { type: "cmd", text: "cat role" },
    { type: "out", text: "Cloud Security Engineer — Microsoft Security · Cloud Security · IAM & Zero Trust" },
    { type: "cmd", text: "cat status" },
    { type: "out", text: "[ OPEN ] Available for remote engagements — worldwide", statusOpen: true }
  ];

  if (reduceMotion) {
    script.forEach(line => body.appendChild(renderTermLine(line, true)));
    appendCursorLine(body);
    return;
  }

  let i = 0;
  function next() {
    if (i >= script.length) { appendCursorLine(body); return; }
    const line = script[i++];
    if (line.type === "cmd") {
      const p = document.createElement("p");
      p.className = "term-line prompt";
      body.appendChild(p);
      typeChars(p, line.text, () => setTimeout(next, 180));
    } else {
      const p = renderTermLine(line, true);
      body.appendChild(p);
      setTimeout(next, 260);
    }
  }
  next();
}

function renderTermLine(line, immediate) {
  const p = document.createElement("p");
  if (line.type === "cmd") {
    p.className = "term-line prompt";
    p.textContent = line.text;
  } else {
    p.className = "term-line out";
    p.innerHTML = line.statusOpen
      ? `[ ${'<span class="status-open">OPEN</span>'} ] Available for remote engagements — worldwide`
      : esc(line.text);
  }
  return p;
}

function typeChars(el, text, done) {
  let i = 0;
  const speed = 22;
  (function tick() {
    el.textContent = text.slice(0, i);
    i++;
    if (i <= text.length) setTimeout(tick, speed);
    else done();
  })();
}

function appendCursorLine(body) {
  const p = document.createElement("p");
  p.className = "term-line prompt";
  p.innerHTML = `<span class="cursor"></span>`;
  body.appendChild(p);
}

renderTabsAndPanes();
typeTerminal();
document.getElementById("year").textContent = new Date().getFullYear();
